import './App.css';
import MainParent from './MainPerant/MainParent';

function App() {
  return (
    <MainParent/>
    );
}

export default App;
